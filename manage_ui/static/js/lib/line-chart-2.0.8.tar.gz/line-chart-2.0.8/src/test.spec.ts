/// <reference path='./angular/LineChart.ts' />

/// <reference path='../typings/angularjs/angular-mocks.d.ts' />
/// <reference path='../typings/mocha/mocha.d.ts' />
/// <reference path='../typings/sinon/sinon.d.ts' />
/// <reference path='../typings/expect.js/expect.js.d.ts' />
