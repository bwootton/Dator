/// <reference path='../src/angular/LineChart.ts' />

/// <reference path='../typings/angular-protractor/angular-protractor.d.ts' />
/// <reference path='../typings/jasmine/jasmine.d.ts' />
