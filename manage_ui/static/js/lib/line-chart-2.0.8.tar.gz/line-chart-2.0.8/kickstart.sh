#! /usr/bin/env bash

npm install
tsd reinstall -s
gulp
